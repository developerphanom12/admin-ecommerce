import React from 'react'

export default function Modal() {
    const [modalIsOpen, setModalIsOpen] = useState(false);

    const openModal = () => {
      setModalIsOpen(true);
    };
  
    const closeModal = () => {
      setModalIsOpen(false);
    };
  return (
    <>
    <PreNav openModal={openModal} />
    <Page1 modalIsOpen={modalIsOpen} closeModal={closeModal} />
  </>
  )
}
